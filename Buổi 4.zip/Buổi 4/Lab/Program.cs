﻿using System;
using System.Collections.Generic;

namespace ExceptionHandling
{
    class Program
    {
        static void Main(string[] args)
        {
            //try
            //{
            //    int[] myNumbers = { 1, 2, 3 };
            //    Console.WriteLine(myNumbers[10]);
            //}
            //catch (Exception e)
            //{
            //    Console.WriteLine(e.Message);
            //}

            try
            {
                int a = 10;
                int b = 0;
                int x = a / b;
            }
            catch (Exception e)
            { 
                Console.WriteLine(e);
            }
            finally
            { 
                Console.WriteLine("Finally block is executed");
            }
            Console.WriteLine("Rest of the code");



            finally_example_if_exception_is_handled();

            // finally_example_if_exception_is_not_handled();

            // TestUserDefinedException();

            //Checked();
            //Unchecked();
            // ExpicitConversion();
            //UserDefinedConversion();
            // StackExample();


        }



        #region: Control Exception
        static void finally_example_if_exception_is_handled()
        {
            try
            {
                int a = 10;
                int b = 0;
                int x = a / b;
            }
            catch (Exception e) { Console.WriteLine(e); }
            finally { Console.WriteLine("Finally block is executed"); }
            Console.WriteLine("Rest of the code");
        }

        static void finally_example_if_exception_is_not_handled()
        {
            try
            {
                int a = 10;
                int b = 0;
                int x = a / b;
            }
            catch (NullReferenceException e) { Console.WriteLine(e); }
            finally { Console.WriteLine("Finally block is executed"); }
            Console.WriteLine("Rest of the code");
        }

        static void TestUserDefinedException()
        {
            try
            {
                validate(12);
            }
            catch (InvalidAgeException e)
            { 
                Console.WriteLine(e); 
            }
            Console.WriteLine("Rest of the code");
        }
        static void validate(int age)
        {
            if (age < 18)
            {
                throw new InvalidAgeException("Sorry, Age must be greater than 18");
            }
        }


        static void Checked()
        {
            checked
            {
                int val = int.MaxValue;
                Console.WriteLine(val + 2);
            }

        }
        static void Unchecked()
        {
            unchecked
            {
                int val = int.MaxValue;
                Console.WriteLine(val + 2);
            }

        }

        #endregion


        #region: Conversion Data Type 

        static void ImplicitConversion()
        {
            int value1 = 567;
            int value2 = 765;
            long summation;
            summation = value1 + value2;
            Console.WriteLine("summation = " + summation);
            Console.ReadLine();
        }

        static void ExpicitConversion()
        {
            double db = 7896.45;
            int xy;
            // here we do the cast double to int, so lose data  
            xy = (int)db;
            Console.WriteLine(xy);
            Console.ReadKey();

        }

        static void UserDefinedConversion()
        {

            Console.WriteLine("Please enter a whole number measurement in meters");
            int nm = Convert.ToInt32(Console.ReadLine());
            ImperialMeasurement im = (ImperialMeasurement)nm;
            Console.WriteLine($"The measument of {nm} in meters is {im.feet} in feet ");
            Console.ReadKey();

        }

        #endregion

        #region: Colections
       
        /// <summary>
        /// Demo for List Type
        /// </summary>
        static void ListExample()
        {
            // Create a list of strings using collection initializer  
            var names = new List<string>() { "Sonoo", "Vimal", "Ratan", "Love" };

            // Iterate through the list.  
            foreach (var name in names)
            {
                Console.WriteLine(name);
            }

        }
        /// <summary>
        /// Demo for HashSet Type
        /// </summary>
        static void HashSetExample()
        {
            // Create a set of strings  
            var names = new HashSet<string>();
            names.Add("Sonoo");
            names.Add("Ankit");
            names.Add("Peter");
            names.Add("Irfan");
            names.Add("Ankit");//will not be added because duplicate item 

            // Iterate HashSet elements using foreach loop  
            foreach (var name in names)
            {
                Console.WriteLine(name);
            }
        }

        static void SortedSetExample()
        {
            // Create a set of strings  
            var names = new SortedSet<string>();
            names.Add("Sonoo");
            names.Add("Ankit");
            names.Add("Peter");
            names.Add("Irfan");
            names.Add("Ankit");//will not be added because duplicate item 

            // Iterate SortedSet elements using foreach loop  
            foreach (var name in names)
            {
                Console.WriteLine(name);
            }
        }


        static void StackExample()
        {
            Stack<string> names = new Stack<string>();
            names.Push("Sonoo");
            names.Push("Peter");
            names.Push("James");
            names.Push("Ratan");
            names.Push("Irfan");

            foreach (string name in names)
            {
                Console.WriteLine(name);
            }

            Console.WriteLine("Peek element: " + names.Peek());// return  object at the top of the Stack
            Console.WriteLine("Pop: " + names.Pop());
            Console.WriteLine("After Pop, Peek element: " + names.Peek());

        }

        static void QueueExample()
        {
            Queue<string> names = new Queue<string>();
            names.Enqueue("Sonoo");
            names.Enqueue("Peter");
            names.Enqueue("James");
            names.Enqueue("Ratan");
            names.Enqueue("Irfan");

            foreach (string name in names)
            {
                Console.WriteLine(name);
            }

            Console.WriteLine("Peek element: " + names.Peek());
            Console.WriteLine("Dequeue: " + names.Dequeue());// remove and return object just was removed
            Console.WriteLine("After Dequeue, Peek element: " + names.Peek());

        }


        static void DictionaryExample()
        {

            Dictionary<string, string> names = new Dictionary<string, string>();
            names.Add("1", "Sonoo");
            names.Add("2", "Peter");
            names.Add("3", "James");
            names.Add("4", "Ratan");
            names.Add("5", "Irfan");

            foreach (KeyValuePair<string, string> kv in names)
            {
                Console.WriteLine(kv.Key + " " + kv.Value);
            }                

        }

        #endregion

        #region: Functions

        static void CallByValue()
        {
            int val = 50;
            Program program = new Program(); // Creating Object  
            Console.WriteLine("Value before calling the function " + val);
            program.Show(val); // Calling Function by passing value            
            Console.WriteLine("Value after calling the function " + val);

        }

        static void CallByReference()
        {
            //int val = 50;// variable need to be initialized
            int val1;
            val1 = 8;
            Program program = new Program(); // Creating Object  
            //Console.WriteLine("Value before calling the function " + val1);
            program.ShowRefer(ref val1); // Calling Function by passing reference            
            Console.WriteLine("Value after calling the function " + val1);

        }

        // User defined function 
        /// <summary>
        /// /// funtion input parameter by value
        /// </summary>
        /// <param name="val"></param>
        public void Show(int val)
        {
            val *= val; // Manipulating value  
            Console.WriteLine("Value inside the show function " + val);
            // No return statement  
        }

        /// <summary>
        /// funtion input parameter by referrence
        /// </summary>
        /// <param name="val"></param>
        public void ShowRefer(ref int  val)
        {
            val *= val; // Manipulating value  
            Console.WriteLine("Value inside the show function " + val);
            // No return statement  
        }

        #endregion


        #region: compare reference and out paramater
        public static string GetNextName(ref int id)
        {
            string returnText = "Next-" + id.ToString();
            id += 1;
            return returnText;
        }
        /// <summary>
        /// Both ref and out are treated differently at run time and they are treated the same at compile time, so methods cannot be overloaded if one method takes an argument as ref and the other takes an argument as an out.
        /// </summary>
        /// <param name="id"></param>
        /// <returns></returns>
        //public static string GetNextName(out int id)
        //{
        //    id = 1;
        //    string returnText = "Next-" + id.ToString();
        //    return returnText;
        //}

        #endregion

    }


    public struct ImperialMeasurement
    {
        public float feet;
        public ImperialMeasurement(float r)
        {
            this.feet = r;
        }
        public static explicit operator ImperialMeasurement(int m)
        {
            float ConversionResult = 3.28f * m;
            ImperialMeasurement temp = new ImperialMeasurement(ConversionResult);
            return temp;
        }
    }

    public class InvalidAgeException : Exception
    {
        public InvalidAgeException(String message) : base(message)
        {

        }
    }


}
