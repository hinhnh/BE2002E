﻿using System;

namespace OOP
{
    class Program
    {
        static void Main(string[] args)
        {
            //Default Constructor Invoked 
            Employee e1 = new Employee();
            Employee e2 = new Employee();
            // e1.display();
            // e2.display();

            // Contructor invoked by paramater
            // Employee e3 = new Employee(101, "Sonoo", 890000f);
            // Employee e4 = new Employee(102, "Mahesh", 490000f);
            // e3.display();
            //e4.display();

            Console.WriteLine("the end");
            Employee e3 = new Employee();

            TestBase();

            Console.ReadKey();
        }


         public static void TestBase()
        {
            var d = new Dog();
            d.showColor();
            d.eat();
        }
    
         public static void TestAbstract()
        {
            Pig pObj = new Pig();
            pObj.animalSound();
            pObj.sleep();


        }
         public  static void TestInterface()
        {
            Circle c = new Circle();
            c.draw();

            Rectangle rt = new Rectangle();
            rt.draw();
        }
    }

    public class Employee
    {
        public int id;
        public String name;
        public float salary;

        //Default Constructor Example
        public Employee()
        {
            Console.WriteLine("Default Constructor Invoked");
            this.id = 99;
        }

        //Parameterized Constructor
        public Employee(int i, String n, float s)
        {
            id = i;
            name = n;
            salary = s;
        }
        public void display()
        {
            Console.WriteLine(id + " " + name + " " + salary);
        }

        //Destructor
        /// <summary>
        /// Note: Destructor can't be public. We can't apply any modifier on destructors.
        /// </summary>
        ~Employee()
        {
            Console.WriteLine("Destructor Invoked");
            this.id = 0;
        }


    }


    #region: Using Base keyword
    public class Animal
    {
        public string color = "white";
        public virtual void eat()
        {
            Console.WriteLine("eating...");
        }

    }
    public class Dog : Animal
    {
        string color = "black";
        public void showColor()
        {
            Console.WriteLine(base.color);
            Console.WriteLine(color);
        }

        public override void eat()
        {
            base.eat();// call method of base  class
            Console.WriteLine("eating bread...");
        }



    }
    #endregion

    #region:Sealed  Modifier
    sealed public class Animal_sealed
    {
        public void eat() { Console.WriteLine("eating..."); }
    }

    ///sealed class cannot be derived by any class
    //public class Dog1 : Animal_sealed
    //{
    //    public void bark() { Console.WriteLine("barking..."); }
    //}


    #endregion



    #region: Abtraction

    // Abstract class
    abstract class Animal_abstract
    {
        // Abstract method (does not have a body)
        public abstract void animalSound();
        // Regular method
        public void sleep()
        {
            Console.WriteLine("Zzz");
        }
    }

    // Derived class (inherit from Animal)
    class Pig : Animal_abstract
    {
        public override void animalSound()
        {
            // The body of animalSound() is provided here
            Console.WriteLine("The pig says: wee wee");
        }
    }




    #endregion

    #region: Interface
    public interface IDrawable
    {
        void draw();
    }
    public class Rectangle : IDrawable
    {
        public void draw()
        {
            Console.WriteLine("drawing rectangle...");
        }
    }
    public class Circle : IDrawable
    {
        public void draw()
        {
            Console.WriteLine("drawing circle...");
        }
    }
    #endregion


}
