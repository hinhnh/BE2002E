﻿using System;
using System.Diagnostics;

namespace DataType
{
    class Program
    {
        #region:comment
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
            object obj;
            obj = 123;
            Console.WriteLine("gia trị cua obj:"+ obj);

            dynamic StringValue = "Nguyen Van A";
            //StringValue++;
            Console.WriteLine("Kich co kieu int la: {0}", sizeof(int));

            bool a1 = true;
            Console.Write("!a" + !a1);


            int a = 5;
            int b = 6;
            int c = 8;
            float tbc = (float)(a + b + c) / 3;
            Console.WriteLine("trung binh cong {0}", tbc);
           

            //double t = 5.4433;
            int d = (int)Math.Round(tbc, 0);
            Console.ReadLine();

            Stopwatch sw = new Stopwatch();

            //first time
            sw.Start();
            KhaibaoKieuData();
            sw.Stop();
            Console.WriteLine($"First calculation: {sw.ElapsedTicks} ticks");

            //second time
            sw.Restart();
            KhaibaoKieuData();
            sw.Stop();
            Console.WriteLine($"Second calculation: {sw.ElapsedTicks} ticks");


          


        }

        /// <summary>
        /// 
        /// </summary>
        static void KhaibaoKieuData()
        {

            // Kiểu số nguyên
            byte BienByte = 10;
            short BienShort = 10;
            int BienInt = 10;
            long BienLong = 10;

            // Kiểu số thực
            float BienFloat = 10.9f; // Giá trị của biến kiểu float phải có hậu tố f hoặc F. 
            double BienDouble = 10.9; // Giá trị của biến kiểu double không cần hậu tố.
            decimal BienDecimal = 10.9m; // Giá trị của biến kiểu decimal phải có hậu tố m.

            // Kiểu ký tự và kiểu chuỗi
            char BienChar = 'K'; // Giá trị của biến kiểu ký tự nằm trong cặp dấu '' (nháy đơn).
            string BienString = "Kteam"; // Giá trị của biến kiểu chuỗi nằm trong cặp dấu "" (nháy kép).

            Console.ReadKey();



        }


        #endregion


    }
}
