﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace BookManaging
{
    class Book : IBook
    {
        private ArrayList chapter = new ArrayList();
        
        public string this[int index] 
        {
            get
            {
                if (index >= 0 && index < chapter.Count)
                    return (string)chapter[index];
                else // ngoai chi so chapter
                    throw new IndexOutOfRangeException();
            } 
            
            set
            {
                if (index >= 0 && index < chapter.Count)
                    chapter[index] = value;
                else
                    if (index == chapter.Count)
                    chapter.Add(value);
                else throw new IndexOutOfRangeException();

            }
                
        
        
        }
                 
        public string Title { get ; set ; }
        public string Author { get ; set; }
        public string Publisher { get; set; }
        public string ISBN { get; set; }
        public int Year { get; set; }

        public void ShowBook()
        {
            Console.WriteLine("---------------");
            Console.WriteLine("Title:" + this.Title);
            Console.WriteLine("Publisher:" + this.Publisher);
            Console.WriteLine("ISBN:" + this.ISBN);
            Console.WriteLine("Year:" + this.Year);
            Console.WriteLine("Chapter:");
            for(int i =0; i <this.chapter.Count; i++)
            {
                Console.WriteLine("\t{0}:{1}", i + 1, chapter[i]);
            }
        }

        public  void InputBook()
        {
            Console.WriteLine("Nhap Title:");
            this.Title = Console.ReadLine();
            Console.WriteLine("Nhap Author:");
            this.Author = Console.ReadLine();
            Console.WriteLine("Nhap Publisher:");
            this.Publisher = Console.ReadLine();
            Console.WriteLine("Nhap ISBN:");
            this.ISBN = Console.ReadLine();

            Console.WriteLine("Nhap Nam:");
            this.Year = int.Parse(Console.ReadLine());
            Console.WriteLine("Nhap chapter(ket thuc khi nhap chuoi rong)");
            string strchap;
            do
            {
                strchap = Console.ReadLine();
                if (strchap.Length > 0) chapter.Add(strchap);

            } while (strchap.Length > 0);


        }


    }

   


}
