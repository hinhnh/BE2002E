﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Diagnostics.CodeAnalysis;
using System.Text;

namespace BookManaging
{
   //Tạo class sắp xếp theo Year tăng dần
    class SortYearAscendingHelper : IComparer
    {
        public int Compare(object a, object b)
        {
            Book c1 = (Book)a;
            Book c2 = (Book)b;
            if (c1.Year > c2.Year)
                return 1;
            if (c1.Year < c2.Year)
                return -1;
            else
                return 0;
        }
    }

    //Tạo class sắp xếp theo Year giảm  dần
    class SortYearDescendingHelper : IComparer
    {
        public int Compare(object a, object b)
        {
            Book c1 = (Book)a;
            Book c2 = (Book)b;
            if (c1.Year < c2.Year)
                return 1;
            if (c1.Year > c2.Year)
                return -1;
            else
                return 0;
        }
    }



}
