﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;

namespace BookManaging
{
    class BookList
    {
        ArrayList list = new ArrayList();

        public void AddBook()
        {
            Book b = new Book();
            b.InputBook();
            list.Add(b);
        }

        public void ShowListBook()
        {
            foreach (Book b in list)
                b.ShowBook();

        }

        public void SortByYearAscending()
        {           
            IComparer SortByYearAscending = new SortYearAscendingHelper();
            list.Sort(SortByYearAscending);               
           
        }

        public void SortByYearDescending()
        {
            IComparer SortByYearDescending = new SortYearDescendingHelper();
            list.Sort(SortByYearDescending);

        }


        public void InputList()
        {

            int n;
            Console.WriteLine("Nhap so luong sach can nhap n =");
            n = int.Parse(Console.ReadLine());

            while( n> 0) {
                AddBook();
                n--;
            }

        }

      

    }
}
