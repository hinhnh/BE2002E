﻿using System;

namespace BookManaging
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = System.Text.Encoding.UTF8;
            BookList bl = new BookList();
            bl.InputList();
            Console.WriteLine("****************************************************************!");
            Console.WriteLine("Truoc khi sap xep!");
            bl.ShowListBook();
                        
            bl.SortByYearAscending();// gọi hàm sắp xếp theo năm xuất bản tăng dần

            Console.WriteLine("****************************************************************!");
            Console.WriteLine("Sau khi sap xep theo year tăng dần!");                      
            bl.ShowListBook();

            bl.SortByYearDescending();// gọi hàm sắp xếp theo năm xuất bản giảm dần
            Console.WriteLine("****************************************************************!");
            Console.WriteLine("Sau khi sap xep theo year giảm dần!");
            bl.ShowListBook();
            Console.WriteLine();
        }
    }
}
