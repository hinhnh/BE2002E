﻿using System;
using System.Linq;
using DemoEFCore.DataContext;
using DemoEFCore.Model;
using Microsoft.Extensions.Caching.Memory;

namespace DemoEFCore
{
    class Program
    {
        static void Main(string[] args)
        {
            // CreateDatabase();

            InsertBlog();
            UpdateBlog(2, "Updated");
            DeleteBlog(3);

            Console.WriteLine("Go bat ky phim nao de thoat...");
            Console.ReadKey();


        }


        public static  void CreateDatabase()
        {
            using (var dbcontext = new BloggingContext())
            {
                bool result =  dbcontext.Database.EnsureCreated();
                string resultstring = result ? "tạo  thành  công" : "đã có trước đó";
                Console.WriteLine($"CSDL - {resultstring}");


            }
        }

        // Thực hiện chèn dữ liệu mẫu, 2 sản phẩm
        public static async void InsertBlog()
        {
            using (var context = new BloggingContext())
            {
                // Dùng đối tượng DbSet để thêm
                await context.Blogs.AddAsync(new Blog
                {
                    Name = "Tin tuc",
                    
                });

                // Dùng context để thêm
                await context.AddAsync(new Blog()
                {
                    Name = "The thao"
                   
                });

                // Thực hiện Insert vào DB các dữ liệu đã thêm.
                int rows = await context.SaveChangesAsync();
                Console.WriteLine($"Đã lưu {rows} vao data base");
            }
        }

        public  static  void ShowBlogs()
        {

            using (var context = new BloggingContext())
            {
                // Lấy List các sản phẩm từ DB
                var blogs =  context.Blogs.ToList();
                Console.WriteLine("Tất cả  các blogs");
                foreach (var blog in blogs)
                {
                    Console.WriteLine($"{blog.BlogId,2} {blog.Name,10}");
                }
                Console.WriteLine();
                Console.WriteLine();

                //Sử dụng LINQ trên DbSet (products)
                
                var querys = from b in context.Blogs.OrderBy(item =>item.Name)  select b;

                Console.WriteLine("Duyet blog dung linQ");
                foreach (var blog in querys)
                {
                    Console.WriteLine($"{blog.BlogId,2} {blog.Name,10}");
                }
            }
        }


        public static void UpdateBlog(int id, string newName)
        {
            using (var context = new BloggingContext())
            {
                               
                var blog = context.Blogs.FirstOrDefault(item => item.BlogId == id);

                if (blog != null)
                {
                    blog.Name = newName;
                    Console.WriteLine($"{blog.BlogId,2} có tên mới = {blog.Name,10}");
                     context.SaveChanges();  //Thi hành cập nhật
                }
            }
        }


        // Xóa sản phẩm có ProductID = id
        public static void DeleteBlog(int id)
        {
            using (var context = new BloggingContext())
            {
                var blog = context.Blogs.FirstOrDefault(item => item.BlogId == id);

                if (blog != null)
                {
                    context.Remove(blog);
                    Console.WriteLine($"Xóa {blog.BlogId}");
                    context.SaveChanges();
                }
            }
        }


    }
}
