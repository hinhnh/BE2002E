﻿using DemoEFCore.Model;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace DemoEFCore.DataContext
{
   public class BloggingContext: DbContext
    {
        // Chuỗi kết nối, có chỉ định tên CSDL sẽ làm việc
        private const string connectionString = "Data Source=DESKTOP-4DCOTR8\\SQL2014;Initial Catalog=BloggingDB;User ID=sa;Password=123456"; 
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            base.OnConfiguring(optionsBuilder);
            optionsBuilder.UseSqlServer(connectionString);// dotnet add package Microsoft.EntityFrameworkCore.SqlServer
        }

        // protected internal virtual void OnModelCreating(Microsoft.EntityFrameworkCore.ModelBuilder modelBuilder);
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {

            //modelBuilder.Entity<Blog>(entity =>
            //{
            //    // Set key for entity
            //    entity.HasKey(p => p.BlogId);
            //});

            base.OnModelCreating(modelBuilder);

            //modelBuilder.Entity<Blog>(entity =>
            //{
            //    entity.Property(e => e.Name)
            //        .HasMaxLength(50)
            //        .IsUnicode(false);

            //    entity.HasOne(d => d.Teacher)
            //        .WithMany(p => p.Course)
            //        .HasForeignKey(d => d.TeacherId)
            //        .OnDelete(DeleteBehavior.Cascade)
            //        .HasConstraintName("FK_Course_Teacher");
            //});
        }
        public DbSet<Blog> Blogs { get; set; }
        public DbSet<Post> Posts { get; set; }

    }
}
