﻿

Install package:

1.dotnet add package Microsoft.EntityFrameworkCore.SqlServer
2.Install-Package Microsoft.EntityFrameworkCore.Tools: to use Migration
2.dotnet add package Microsoft.EntityFrameworkCore.Design


step1: enable-migration
step2 scripts create or update data base with migration:  add-migration CreateSchoolDB
step3 run  command: update-database –verbose
