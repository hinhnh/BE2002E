﻿using System;
using System.Collections.Generic;
using System.Text;

namespace DemoEFCore.Model
{
   public class Blog
    {
        public int BlogId { get; set; }
        public string Name { get; set; }

        public string Url { get; set; } // thêm thuộc tính mới --- dammio.com

        public virtual List<Post> Posts { get; set; }

    }
}
