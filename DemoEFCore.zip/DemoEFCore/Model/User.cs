﻿using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Text;

namespace DemoEFCore.Model
{
    public class User
    {
        public string Username { get; set; }
        public string DisplayName { get; set; }

        public DbSet<User> Users { get; set; }  // thêm mới DbSet User

    }
}
