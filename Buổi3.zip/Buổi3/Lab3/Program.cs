﻿using System;
using System.Text;

namespace Bai3
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.OutputEncoding = Encoding.Unicode;
            Console.InputEncoding = Encoding.Unicode;
            //DemoString();
            //DemoStringBuilder();
            //CountString();
            //FindCharactersShowMax();
            //SortString();
            PrintElementShowOneTimeInArray();
            //InsertElementIntoArray();
            //RemoveSpaceInString();

        }


        static void DemoStringBuilder()
        {
            string a = "";
            for (int i = 0; i < 10; i++)
            { a = a + i.ToString(); }

            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < 10; i++)
            {
                sb.Append(i.ToString());
            }

            Console.WriteLine("a: {0}", a);
            Console.WriteLine("sb: {0}", sb);
            Console.ReadKey();
        }
        static void DemoString()
        {
            Console.WriteLine("Các cách tạo chuỗi trong C#");
            Console.WriteLine("-------------------------------------");

            //su dung phep gan hang chuoi va toan tu noi chuoi
            string fname, lname;
            fname = "Hồ Chí";
            lname = "Minh";

            string fullname = fname + " " + lname;
            Console.WriteLine("Họ và tên: {0}", fullname);

            //su dung constructor cua lop string
            char[] letters = { 'H', 'e', 'l', 'l', 'o' };
            string greetings = new string(letters);
            Console.WriteLine("\nLời chào bằng tiếng Anh: {0}", greetings);

            //tu cac phuong thuc ma tra ve mot chuoi
            string[] sarray = { "T3h", "xin", "chao", "cac", "ban" };
            string message = String.Join(" ", sarray);
            Console.WriteLine("\nThong diep: {0}", message);

            //dinh dang phuong thuc de chuyen doi mot gia tri
            DateTime waiting = new DateTime(2016, 8, 1, 17, 58, 1);
            string chat = String.Format("Thong diep duoc gui luc {0:t} ngay {0:D}", waiting);
            Console.WriteLine("\nThong diep: {0}", chat);

            Console.ReadKey();

            string[] starray = new string[]{"Hoc C# co ban va nang cao tai T3H.",
             "Chuong nay trinh bay ve chuoi trong C#.",
             "Chung ta dang tim hieu ve noi chuoi trong C#."};
            string str = String.Join("\n", starray);
            string str1 = String.Join("-", starray);
            Console.WriteLine(str1);
            String strHN = "Hà Nội";

            Console.WriteLine(strHN);
            Console.ReadKey();
        }
        static void CountString()
        {

            string str; //khai bao chuoi
            int chu_cai, chu_so, ky_tu_dac_biet, i, l;
            chu_cai = chu_so = ky_tu_dac_biet = i = 0;

            Console.Write("\nDem so chu cai, so chu so, so ky tu dac biet cua chuoi trong C#:\n");
            Console.Write("--------------------------------------------------------------------\n");
            Console.Write("Nhap chuoi: ");
            str = Console.ReadLine();
            l = str.Length;

            /* kiem tra tung ky tu trong chuoi*/

            while (i < l)
            {
                if ((str[i] >= 'a' && str[i] <= 'z') || (str[i] >= 'A' && str[i] <= 'Z'))
                {
                    chu_cai++;
                }
                else if (str[i] >= '0' && str[i] <= '9')
                {
                    chu_so++;
                }
                else
                {
                    ky_tu_dac_biet++;
                }

                i++;
            }

            Console.Write("So chu cai trong chuoi la: {0}\n", chu_cai);
            Console.Write("So chu so trong chuoi la: {0}\n", chu_so);
            Console.Write("So ky tu dac biet trong chuoi la: {0}\n\n", ky_tu_dac_biet);

            Console.ReadKey();
        }

        static void FindCharactersShowMax()
        {
            string str; //khai bao mot chuoi
            int[] tan_suat = new int[255];
            int i = 0, max, l;
            int ascii;

            Console.Write("\nTim ky tu xuat hien nhieu nhat trong chuoi C#:\n");
            Console.Write("--------------------------------------------------\n");
            Console.Write("Nhap mot chuoi: ");
            str = Console.ReadLine();
            l = str.Length;

            for (i = 0; i < 255; i++)  //thiet lap tan suat xuat hien cua tat ca ky tu ve 0  
            {
                tan_suat[i] = 0;
            }
            /* Doc tan suat cua moi ky tu */
            i = 0;
            while (i < l)
            {
                ascii = (int)str[i];
                tan_suat[ascii] += 1;
                Console.WriteLine("Ma ascii  của ký tự {0} là {1}", str[i], ascii);
                // Console.WriteLine("Ma ascii  của ký tự {0} là {1}", str[255], ascii);
                i++;
            }

            max = 0;
            for (i = 0; i < 255; i++)
            {
                if (i != 32)
                {
                    if (tan_suat[i] > tan_suat[max])
                        max = i;
                }
            }
            Console.Write("Ky tu xuat hien nhieu nhat '{0}' va xuat hien {1} lan.\n\n", (char)max, tan_suat[max]);

            Console.ReadKey();
        }

        static void SortString()
        {
            string[] arr1;
            string temp;
            int n, i, j, l;

            Console.Write("\nSap chuoi trong C# - su dung Bubble Sort:\n");
            Console.Write("-----------------------------------------------------\n ");
            Console.Write("Nhaphuoi can sap xep: ");
            n = Convert.ToInt32(Console.ReadLine());
            arr1 = new string[n];
            Console.Write("Nhapchuoi tu ban phim:\n", n);
            for (i = 0; i < n; i++)
            {
                arr1[i] = Console.ReadLine();
            }
            l = arr1.Length;

            for (i = 0; i < l; i++)
            {
                for (j = 0; j < l - 1; j++)
                {
                    if (arr1[j].CompareTo(arr1[j + 1]) > 0)
                    {
                        //cach thuc trao doi gia tri
                        temp = arr1[j];
                        arr1[j] = arr1[j + 1];
                        arr1[j + 1] = temp;
                    }
                }
            }
            Console.Write("\nIntu cac chuoi sau khi da sap xep: \n");
            for (i = 0; i < l; i++)
            {
                Console.WriteLine(arr1[i] + " ");
            }

            Console.ReadKey();

        }

        static void PrintElementShowOneTimeInArray()
        {
            int n, bien_dem = 0;
            int[] arr1 = new int[100];
            int i, j, k;


            Console.Write("\nIn cac phan tu duy nhat cua mang trong C#:\n");
            Console.Write("------------------------------------------\n");

            Console.Write("Nhap so phan tu can luu giu vao trong mang: ");
            n = Convert.ToInt32(Console.ReadLine());

            Console.Write("Nhap {0} phan tu vao trong mang:\n", n);
            for (i = 0; i < n; i++)
            {
                Console.Write("Phan tu - {0}: ", i);
                arr1[i] = Convert.ToInt32(Console.ReadLine());
            }

            /*kiem ta cac phan tu giong nhau*/
            Console.Write("\nCac phan tu duy nhat duoc tim thay trong mang la: \n");
            for (i = 0; i < n; i++)
            {
                bien_dem = 0;

                /*kiem tra cac phan tu giong nhau truoc vi tri hien tai va  
                tang bien_dem them 1 neu tim thay.*/
                for (j = 0; j < i - 1; j++)
                {
                    /*tang bien dem khi tim thay phan tu giong nhau.*/
                    if (arr1[i] == arr1[j])
                    {
                        bien_dem++;
                    }
                }
                /*kiem tra cac phan tu giong nhau sau vi tri hien tai va  
                tang bien_dem them 1 neu tim thay.*/
                for (k = i + 1; k < n; k++)
                {
                    /*tang bien dem khi tim thay phan tu giong nhau.*/
                    if (arr1[i] == arr1[k])
                    {
                        bien_dem++;
                    }
                }
                /*In gia tri cua vi tri hien tai trong mang - la gia tri duy nhat 
                khi con tro van chua gia tri ban dau cua no.*/
                if (bien_dem == 0)
                {
                    Console.Write("{0} ", arr1[i]);
                }
            }
            Console.Write("\n\n");

            Console.ReadKey();

        }

        static void InsertElementIntoArray()
        {
            int[] arr1 = new int[10];
            int i, n, p = 0, phan_tu_moi;
            Console.Write("\nChen phan tu vao mang trong C#:\n");
            Console.Write("--------------------------------\n");

            Console.Write("Nhap kich co mang: ");
            n = Convert.ToInt32(Console.ReadLine());
            /* nhap cac phan tu vao trong mang*/
            Console.Write("Nhap {0} phan tu vao mang theo thu tu tang dan:\n", n);
            for (i = 0; i < n; i++)
            {
                Console.Write("Phan tu - {0}: ", i);
                arr1[i] = Convert.ToInt32(Console.ReadLine());
            }
            Console.Write("Nhap gia tri phan tu can chen: ");
            phan_tu_moi = Convert.ToInt32(Console.ReadLine());
            Console.Write("In mang truoc khi chen:\n ");
            for (i = 0; i < n; i++)
                Console.Write("{0} ", arr1[i]);
            /* xac dinh vi tri de chen phan tu moi.*/
            for (i = 0; i < n; i++)
                if (phan_tu_moi < arr1[i])
                {
                    p = i;
                    break;
                }
            /* di chuyen vi tri tat ca phan tu ben canh phai cua mang */
            for (i = n; i >= p; i--)
                arr1[i] = arr1[i - 1];
            /* chen phan tu moi vao vi tri thich hop */
            arr1[p] = phan_tu_moi;

            Console.Write("\n\nSau khi chen, mang co cac phan tu:\n ");
            for (i = 0; i <= n; i++)
                Console.Write("{0} ", arr1[i]);
            Console.Write("\n");

            Console.ReadKey();
        }

        static void RemoveSpaceInString()
        {
            string s = "    Hello  Everybody.    I   am       Peter  ";
            Console.WriteLine("Chuoi truoc khi xoa dau cach: {0}", s);
            s = s.Trim();// xóa khoảng trắng đầu và cuối
            
            while (s.Contains("  ")) //2 khoảng trắng
            {
                s = s.Replace("  ", " "); //Replace 2 khoảng trắng thành 1 khoảng trắng
            }
            Console.WriteLine("Chuoi sau khi xoa dau cach: {0}", s);
            Console.ReadKey();
        }
    }
}
